package com.nopcommerce.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class NopCommerceTest {

    public static void main(String[] args) {
        // Set the system property for Edge WebDriver
        System.setProperty("webdriver.edge.driver", "D:\\edgedriver_win64\\msedgedriver.exe");

        // Create a new instance of EdgeDriver
        WebDriver driver = new EdgeDriver();

        try {
            // Open the website
            driver.get("https://demo.nopcommerce.com/");

            // Click on Register link
            WebElement registerLink = driver.findElement(By.className("ico-register"));
            registerLink.click();

            // Fill in registration form
            WebElement firstNameInput = driver.findElement(By.id("FirstName"));
            firstNameInput.sendKeys("John");

            WebElement lastNameInput = driver.findElement(By.id("LastName"));
            lastNameInput.sendKeys("Doe");

            // Generate a unique email address
            String email = "john.doe" + System.currentTimeMillis() + "@example.com";
            WebElement emailInput = driver.findElement(By.id("Email"));
            emailInput.sendKeys(email);

            WebElement passwordInput = driver.findElement(By.id("Password"));
            passwordInput.sendKeys("password123");

            WebElement confirmPasswordInput = driver.findElement(By.id("ConfirmPassword"));
            confirmPasswordInput.sendKeys("password123");

            WebElement registerButton = driver.findElement(By.id("register-button"));
            registerButton.click();

            // Verify registration success message
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement registrationSuccessMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".result")));
            String registrationMessage = registrationSuccessMessage.getText();
            if (registrationMessage.contains("Your registration completed")) {
                System.out.println("Registration successful.");
            } else {
                System.out.println("Registration failed.");
            }

            // Navigate to login page
            driver.get("https://demo.nopcommerce.com/login");

            // Fill in login form with the newly created email
            WebElement emailLoginInput = driver.findElement(By.id("Email"));
            emailLoginInput.sendKeys(email);

            WebElement passwordLoginInput = driver.findElement(By.id("Password"));
            passwordLoginInput.sendKeys("password123");

            // Move to the login button before clicking
            WebElement loginButton = driver.findElement(By.cssSelector(".login-button"));
            Actions actions = new Actions(driver);
            actions.moveToElement(loginButton).click().perform();

            // Verify login success
            // Wait for the account link to be visible
            //WebElement accountLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".account")));

            driver.get("https://demo.nopcommerce.com/customer/info");

            // Wait for the first name input field to be visible
            try {
                WebElement firstNameElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FirstName")));
                // Get the value of the first name input field
                String loggedinFirstName = firstNameElement.getAttribute("value");

                // Wait for the last name input field to be visible
                WebElement lastNameElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("LastName")));
                // Get the value of the last name input field
                String loggedinLastName = lastNameElement.getAttribute("value");

                // Check if the retrieved values match the expected values
                if (loggedinFirstName.equals("John") && loggedinLastName.equals("Doe")) {
                    System.out.println("Login successful.");
                } else {
                    System.out.println("Login failed.");
                }
            } catch (Exception e) {
                System.out.println("Unable to retrieve login information: " + e.getMessage());
            }

        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
